"use strict";

document.getElementById("btn").onclick = function () {
  var data1 = document.getElementById("x1").value;
  var data2 = document.getElementById("x2").value;
  var data3 = document.getElementById("x3").value;

  console.log(isNaN(data1));
  console.log(data1);
  console.log(data2);
  console.log(data3);

  var msg = "";
  if (data1 == "" || data2 == "" || data3 == "") {
    msg = "plz enter all fields";
  } else if (isNaN(data1) || isNaN(data2) || isNaN(data3)) {
    msg = "all fields should be numberic values";
  } else if (data1 < 0 || data2 < 0 || data3 < 0) {
    msg = "all fields should be positive values";
  } else {
    var p = Number(data1);
    var r = parseFloat(data2);
    var t = parseInt(data3);

    r = r / 100;
    t = t * 12;
    var simpleinterst = (p * r * t) / 100;
    var totalamount = simpleinterst + p;

    document.getElementById("y1").innerHTML = p;
    document.getElementById("y2").innerHTML = simpleinterst;
    document.getElementById("y3").innerHTML = totalamount;
  }
  document.getElementById("result").innerHTML = msg;
};
