"use strict";
class auth {
  constructor() {
    this.details = [
      {
        email: "abc@gmail.com",
        password: "H@fjgh#2",
      },
      {
        email: "xyz@gmail.com",
        password: "3456578",
      },
      {
        email: "pqr@gmail.com",
        password: "8909827398",
      },
      {
        email: "sdf@gmail.com",
        password: "Piyueiu#123",
      },
    ];
  }
  checkemail(emailid) {
    console.log(emailid);
    var exp =
          /^([a-zA-Z0-9]+)@([a-zA-Z0-9]+)\.([a-zA-Z]{2,})(\.[a-zA-Z]{2,})?$/;
      var result = exp.test(emailid);
      return result;
  }
    checkpass(password) {
        var exp1 = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#\.]).{4,12}$/;
        var result = exp1.test(password);
        return result;
  }
    checkemailandpass() {
      
  }
}
export default auth;
